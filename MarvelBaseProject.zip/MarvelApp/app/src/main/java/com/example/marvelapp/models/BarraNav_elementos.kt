package com.example.marvelapp.models

import androidx.annotation.StringRes
import com.example.marvelapp.R

enum class Rutas{
    home,
    personajes,
    publicaciones,
    noticias
}

sealed class Elementos(
    val ruta:String,
    @StringRes val titulo:Int,
    val icono:Int,
    val IconoSelect:Int
){
    object Home: Elementos(
        Rutas.home.name,
        R.string.str_home,
        R.drawable.hogar,
        R.drawable.hogar

    )
    object Personajes: Elementos(
        Rutas.personajes.name,
        R.string.str_personajes,
        R.drawable.hogar,
        R.drawable.hogar
    )
    object Publicaciones: Elementos(
        Rutas.publicaciones.name,
        R.string.str_publis,
        R.drawable.hogar,
        R.drawable.hogar

    )
    object Noticias: Elementos(
        Rutas.noticias.name,
        R.string.str_noticias,
        R.drawable.hogar,
        R.drawable.hogar

    )
}