package com.example.marvelbaseproject.ui.theme

import androidx.compose.ui.graphics.Color

val RojoComic = Color(0xFFEC1D24)
val Blanco = Color(0xFFFEFEFE)
val Negro = Color(0xFF151515)
val AzulGris = Color(0xFF4C5067)
val AzulComic = Color(0xFF0075FF)
val Gris = Color(0xFF767676)
val GriOscuro = Color(0xFF393939)
