

package com.example.marvelapp

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.marvelbaseproject.ui.theme.akshar

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PantallaNoticias(){
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(15.dp)
            .background(
                MaterialTheme.colorScheme.background
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.padding(20.dp)
        ) {
            stickyHeader {
                Row(
                    modifier = Modifier.background(Color(0xFFFEFEFE))
                ) {
                    Text (
                        text = "Noticias",
                        fontSize = 32.sp,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .fillMaxWidth()
                    )
                }
            }

        }

        segmentoNoticiaUno(
            imagen = R.drawable.marvel1,
            titulo = "Nuevo récord de venta de entradas para Deadpool y Wolverine",
            texto = "Deadpool y Wolverine continúa batiendo récords de cara a su estreno el próximo verano. Ahora, la película del Universo Cinematográfico de Marvel ha establecido un nuevo récord entre las películas con clasificación R/+18."
        )

        segmentoNoticiasDos(
            titulo = "Tráiler y fecha para la experiencia VR What If…? – An Immersive Story",
            texto = "Después de su anuncio el pasado mes de mayo, ya tenemos fecha de lanzamiento y primer tráiler para el juego/experiencia de realidad virtual What If…? – An Immersive Story. Este título nace de una colaboración entre Marvel Studios e ILM Immersive, y es la primera historia original interactiva de Disney+."
        )

        segmentoNoticiasTres(
            titulo = "Anunciadas dos nuevas series de cómic de Spider-Man para los más pequeños",
            texto = "Marvel Comics ha anunciado dos nuevas series de Spider-Man dirigidas a los lectores más jóvenes. Las series debutarán este mismo año y presentarán a Peter Parker y el resto del Spider-Verso en un nivel perfecto para los nuevos lectores, pero sin dejar de ofrecer aventuras emocionantes para todos los fans.",
            imagen = R.drawable.marvel3
        )

        segmentoNoticiaUno(
            titulo = "Marvel confirma la serie de televisión de la Visión para 2026",
            texto = "Aunque sabíamos que estaba en desarrollo, al fin se hace oficial que Marvel Studios lanzará una serie de televisión spin-off de Bruja Escarlata y Visión protagonizada por la Visión. Aunque previamente la conocíamos como Vision Quest, Variety apunta a que la serie aún no tiene título, pero está previsto su estreno para 2026 en Disney+.",
            imagen = R.drawable.marvel4
        )
    }
}

@Composable
fun segmentoNoticiaUno(imagen: Int, titulo: String, texto: String){
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp)
            .background(
                Color(0xFF76767),
                shape = RoundedCornerShape(15.dp)
            )
    ) {
        Image(
            painter = painterResource(id = imagen),
            contentDescription = null,
            modifier = Modifier
                .fillMaxWidth()
                .height(70.dp),
            contentScale = ContentScale.Crop
        )

        Text(
            text = titulo,
            fontSize = 16.sp,
            fontFamily = akshar,
            style = MaterialTheme.typography.titleSmall,
        )

        Text(
            text = texto,
            fontSize = 16.sp,
            fontFamily = akshar,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun segmentoNoticiasDos(titulo: String, texto: String){
    Row (
        modifier = Modifier
            .fillMaxWidth()
            .padding(5.dp)
    ) {
        Text(
            text = titulo,
            fontSize = 16.sp,
            fontFamily = akshar,
            style = MaterialTheme.typography.titleSmall,
        )

        Text(
            text = texto,
            fontSize = 16.sp,
            fontFamily = akshar,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
fun segmentoNoticiasTres(titulo: String, texto: String, imagen: Int){
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp)
            .background(
                Color(0xFF76767),
                shape = RoundedCornerShape(15.dp)
            )
    ){
        Text(
            text = titulo,
            fontSize = 16.sp,
            fontFamily = akshar,
            style = MaterialTheme.typography.titleSmall,
        )

        Text(
            text = texto,
            fontSize = 16.sp,
            fontFamily = akshar,
            style = MaterialTheme.typography.bodyMedium
        )

        Image(
            painter = painterResource(id = imagen),
            contentDescription = null,
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            contentScale = ContentScale.Crop
        )

    }
}



@Preview
@Composable
fun NoticiasPreview(){
    PantallaNoticias()
}

